import "./App.css";
import { useClickOutside } from "./hooks/use-click-outside";
import { useNetwork } from "./hooks/use-network";

function App() {
  const { online } = useNetwork();
  const btnRef = useClickOutside(() => {});
  return (
    <div>
      <div>Demo hooks</div>
      <div>is online:{online ? "true" : "false"}</div>
      <button
        ref={btnRef}
        style={{
          padding: 10,
          background: "blue",
          color: "white",
          border: "1px solid black",
          borderRadius: 5,
        }}
      >
        Check hook click out side
      </button>
    </div>
  );
}

export default App;
